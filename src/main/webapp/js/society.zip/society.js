var url = window.location.href;

var arr = url.split('?');
//var arr1 = arr[1].split('=');
//console.log("Id: " + arr1[1]);
var orgId = getStorageData(KEY_ORG_ID);
var orgName = "";
console.log("orgId: " + orgId);

$(document).ready(function() {

    $("a[data-toggle=\"tab\"]").on("shown.bs.tab", function(e) {
        //console.log( 'show tab' );
        $($.fn.dataTable.tables(true)).DataTable()
            .columns.adjust()
            .responsive.recalc();
        setStorageData(KEY_STATE_SOC, $(this).attr('data-target'));
    });

    var tb = getStorageData(KEY_STATE_SOC);

    if (tb != null) {
        // soctab
        $('#myTab a[data-target="' + tb + '"]').tab('show');
    }

    // 1. Dashboard view: starts for society admin
	var populateDashboard = function(){
		$("#dashLoadingDiv").show();
		$("#dashboardDiv").hide();
		var dashUrl = "api/dashboards/admin?orgId=" + orgId;
		ajaxRequest(null, "GET", dashUrl, function(response) {
				var dashData = response.data;
				for (i = 0; i < dashData.length; i++) {
					if(i >= 5){
						// Need to show max 5 dashboards
						break;
					}
					$("#d"+i).html(htmlEncode(dashData[i].displayText));
					$("#v"+i).html(htmlEncode(dashData[i].value));
					$("#d"+i).attr('title',htmlEncode(dashData[i].displayText));
				}
				$("#dashLoadingDiv").hide();
				$("#dashboardDiv").show();

			}, null
		);
	};
    populateDashboard();
    // 1. Dashboard view: ends

    // 2. Society details: starts
    var populateSocData = function() {
        url = "api/orgs/" + orgId;
        ajaxRequest(null, "GET", url, populateSocDetails, null);
    }

    var populateSocDetails = function(response) {
        // set the name of the society
        var data = response.data;

        var socName = data.name;
        orgName = socName;
        var noOfUnits = data.numOfunit;
        //console.log(socName + "(" + noOfUnits + ")");
        var socStr = socName;
        if(!isEmpty(noOfUnits)){
        	socStr = socStr + " (" + noOfUnits + " Units)";
        }
        $("#socName").html(htmlEncode(socStr));
		$("#editSociety").show();
        // basic license info
        var line1 = "";
        var line2 = "";
        var landmark = "";
        var city = "";
        var state = "";
        var country = "";

        if (data != null && data.address != null) {
            if (data.address.line1 != null) {
                line1 = data.address.line1;
            }

            if (data.address.line2 != null) {
                line2 = data.address.line2;
            }


            if (data.address.landmark != null) {
                landmark = data.address.landmark;
            }

            city = data.address.city.name;
            state = data.address.city.state.name;
            country = data.address.city.state.country.name;

            $("#addLines").html(htmlEncode(line1 + ", " + line2));
            $("#landmark").html(htmlEncode(landmark));
            $("#cityCountry").html(htmlEncode(city + ", " + state + ", " + country));
        }


        if (data.contact != null) {
            var fname = data.contact.firstName;
            var lname = data.contact.lastName;
            var nameStr = "";
            if(!isEmpty(fname)){
            	nameStr = nameStr + fname;
            }

            if(!isEmpty(lname)){
            	nameStr = nameStr + " " + lname;
            }

            $("#cname").html(htmlEncode(nameStr));

			if(data.contact.email != null){
				var email = data.contact.email.address;
				$("#cemail").html(htmlEncode(email));
			}

			if(data.contact.phone != null){
				var mob = data.contact.phone.number;
				$("#cmob").html(htmlEncode(mob));
			}

        }

		if(!isEmpty(data.subsExpiryDate)){
			if(hasSubsExpired(data.subsExpiryDate)){
				$("#societySubExpired").show();
			}else{
				if(isSubsExpiringSoon(data.subsExpiryDate)){
					$("#societySubExpiring").show();
				}
			}
		}else{
			$("#societySubInfo").show();
		}

		$("#socLoadingDiv").hide();
		$("#socDetailsDiv").show();

    };

    populateSocData();

    $('#editSociety').on('click', function() {
        // pass the selected row to the edit page
        setStorageData(KEY_ORG_ID, orgId);
		setStorageData(KEY_ORG_NAME, orgName);
		window.location.href = "../html/society.html?action=edit&src=dtl";
		return false;
    });
    // 2. Society details: ends

    // 3. Users tab data: starts
	var usersDataSet = [];
	var populateUsersTable = function(data) {
	    var usersdata = [];
	    usersDataSet = [];
	    usersdata = data.data;

	    for (i = 0; i < usersdata.length; i++) {
	        var tempdata = [];

	        tempdata.push(usersdata[i].id);
	        tempdata.push(usersdata[i].name);

	        if (usersdata[i].status == 4) {
	        	tempdata.push("Yes");
	        } else {
	        	tempdata.push("No");
	        }

	        if (usersdata[i].active == true)
	            tempdata.push("Active");
	        else
	            tempdata.push("Inactive");

	        //tempdata.push(socdata[i].address.line1);
	        if (usersdata[i].email != null)
	            tempdata.push(usersdata[i].email.address);
	        else
	            tempdata.push("");

	        if (usersdata[i].phone != null)
	            tempdata.push(usersdata[i].phone.countryCode+usersdata[i].phone.number);
	        else
	            tempdata.push("");

			if (usersdata[i].unit != null)
	            tempdata.push(usersdata[i].unit.shortName);
	        else
	            tempdata.push("");

			var roles = "";
			if(usersdata[i].roles != null){
				for(var j=0;j<usersdata[i].roles.length;j++){
					if(j>0){
						roles += ", ";
					}
					roles += usersdata[i].roles[j].name;
				}
			}
			tempdata.push(roles);

	        tempdata.push(usersdata[i].id);
	        usersDataSet.push(tempdata);
	    };

	    var tb = $("#UsersTable").dataTable();
        tb.fnClearTable();
		if(usersDataSet != null && usersDataSet.length > 0){
			tb.fnAddData(usersDataSet);

		}
	};

	var getAllUsers = function() {
	    var url = "api/orgs/" + orgId + "/users?allStatus=true";
	    ajaxRequest(null, "GET", url, populateUsersTable, null);
	};

	getAllUsers();

	var table = $("#UsersTable").dataTable({
		data: usersDataSet,
		responsive: true,
		bLengthChange: false,
		//"deferRender": true,
		columns: [{ title: "ID" },
			{ title: "Name" },
			{ title: "Approved" },
			{ title: "Status" },
			{ title: "email" },
			{ title: "Mobile" },
			{ title: "Unit" },
			{ title: "Roles" }
		],
		columnDefs: [{
			"targets": [0],
			"visible": false,
			"searchable": false
		}]
	});
	// 3. Users tab data: ends

	// 4. Users functionalities: starts

    // Edit User: Starts
    var initEditUser = function() {


        // pass the selected row to the edit page
        var table1 = $('#UsersTable').DataTable();
        var tdata = table1.rows('.selected').data();
        var userid = tdata[0][0];
        setStorageData(KEY_USER_ID, userid);

    	window.location.href = "user.html?action=update";

    };
    $('#editUser').on('click', initEditUser);
	$('#editUser1').on('click', initEditUser);
    // Edit User: Ends

    // Delete User: Starts
    var initDelUser = function() {
        var table1 = $('#UsersTable').DataTable();
        var tdata = table1.rows('.selected').data();
        var userid = tdata[0][0];

        var myurl = "api/users/" + userid;
        var delUserData = {};
        delUserData.active = false;
        ajaxRequest(delUserData, "PUT", myurl, deleteUserSuccess, null);
    };
	$("#delUser").on('click', initDelUser);
	$("#delUser1").on('click', initDelUser);

    var deleteUserSuccess = function(response) {
        getAllUsers();
        showMessage('User deleted successfully.', 'success');
    };
    // Delete User: Ends


    // Approve User: Starts
    var initApproverUser = function() {
        var table1 = $('#UsersTable').DataTable();
        var tdata = table1.rows('.selected').data();
        console.log("approval data");
        console.log(tdata);
        var userid = tdata[0][0];

        var verData = {};
        verData.status = 4;
        var myurl = "";
        var callbackFunc = null;
        for (j = 0; j < tdata.length; j++) {
            myurl = "api/users/";
            userid = tdata[j][0];
            //console.log(tdata[j][0]);
            myurl = myurl + userid;
            if(j == tdata.length - 1){
            	callbackFunc = approveUserSuccess;
            }
            ajaxRequest(verData, "PUT", myurl, callbackFunc, null);
        }

    };
	$('#verUser').on('click', initApproverUser);
	$('#verUser1').on('click', initApproverUser);

    var approveUserSuccess = function(response) {
        getAllUsers();
        showMessage('User(s) approved successfully.', 'success');
		populateDashboard();
    };
    // Approve User: Ends

    // Activate / Deactivate User: Starts
    var initActUser = function() {
        var table1 = $('#UsersTable').DataTable();
        var tdata = table1.rows('.selected').data();
        console.log("approval data");
        console.log(tdata);
        var userid = tdata[0][0];
        // + userid;

        var verData = {};

        //verData["status"]=4;
        var myurl = "";
        var callbackFunc = null;
        for (j = 0; j < tdata.length; j++) {
        	var status = tdata[j][3];

            console.log("Here am i : " + status);

            if (status == "Active") {
                verData["active"] = false;
            } else {
                verData["active"] = true;
            }
            myurl = "api/users/";
            userid = tdata[j][0];
            //console.log(tdata[j][0]);
            myurl = myurl + userid;
            if(j == tdata.length - 1){
            	callbackFunc = actDeactUserSuccess;
            }
            ajaxRequest(verData, "PUT", myurl, callbackFunc, null);
        }

    };
	$('#actDactUser').on('click', initActUser);
	$('#actDactUser1').on('click', initActUser);

    var actDeactUserSuccess = function(response) {
        getAllUsers();
        showMessage('User(s) activated / deactivated successfully.', 'success');
		populateDashboard();
    };

    //Activate / Deactivate User: Ends

	// 4. Users functionalities: ends

    // 5. Units functionalities: Starts

    // 5.a. Display Units data: Starts
    var unitsDataSet = [];
    //var myUnitsData = [];
    var populateUnitsTable = function(data) {
       // myUnitsData = data.data;

        var unitsdata = data.data;
        unitsDataSet = [];

        //op_needed = [];
        var tempdata = [];
        //$("#unitListAdd").empty(); // This is from Add user unit list
        //$("#unitList").empty();
        $("#parentList").empty();
        for (var i = 0; i < unitsdata.length; i++) {
            var myunit = {};

            tempdata = [];
            var id = unitsdata[i].id;

            var name = "";
            if(unitsdata[i].hasOwnProperty("name")){
            	name = unitsdata[i].name;
            }

            var shortname = "";
            if(unitsdata[i].hasOwnProperty("shortName")){
            	shortname = unitsdata[i].shortName;
            }

            console.log("Adding options");
            //var o = new Option(shortname, id);
            //var o1 = new Option(shortname, id);
            var o2 = new Option(shortname, id);

            //$("#unitListAdd").append($(o));
            //$("#unitList").append($(o1));
            $("#parentList").append($(o2));

            var location = "";
            if(unitsdata[i].hasOwnProperty("location")){
            	location = unitsdata[i].location;
            }
            var type;
            if (unitsdata[i].type != null) {
                type = unitsdata[i].type.name;
            } else {
                type = " ";
            }

            var parentUnit = "";
            if (unitsdata[i].hasOwnProperty("parentUnit")) {
                //console.log(unitsdata[i]);
                parentUnit = unitsdata[i].parentUnit.name;
            }

            tempdata.push(id);
            tempdata.push(name);
            tempdata.push(shortname);
            tempdata.push(location);
            tempdata.push(type);
            tempdata.push(parentUnit);
            unitsDataSet.push(tempdata);
        }

		var tb = $("#UnitsTable").dataTable();
        tb.fnClearTable();
        if (unitsDataSet.length > 0) {
            tb.fnAddData(unitsDataSet);
        }

    };

    var getAllUnits = function() {
        var url = "api/orgs/" + orgId + "/hierarchy?hierarchyType=flat";
        ajaxRequest(null, "GET", url, populateUnitsTable, null);
    };

    getAllUnits();

	var unittable = $("#UnitsTable").dataTable({
			data: unitsDataSet,
			responsive: true,
			bLengthChange: false,
			//"deferRender": true,
			columns: [
					  { title: "ID" },
					  { title: "Name" },
					  { title: "ShortName" },
					  { title: "Location" },
					  { title: "Type" },
					  { title: "Parent" }
				],
			columnDefs: [{
				"targets": [0],
				"visible": false,
				"searchable": false
			}]
		});

    // 5.a. Display Units data: Ends

    // 5.b. Create Unit: Starts

    // 5.b. Create Unit: Starts
    // 5.c. Edit Unit
    var initEditUnit = function() {
        var table1 = $('#UnitsTable').DataTable();
        var tdata = table1.rows('.selected').data();
        var unitId = tdata[0][0];
        setStorageData(KEY_UNIT_ID, unitId);
    	window.location.href = "unit.html?action=update";

        //editUnit();
    };
	$("#editUnit").on('click', initEditUnit);
	$("#editUnit1").on('click', initEditUnit);

    // 5.d. Delete unit: Starts

    var delUnitSuccess = function(res){
    	showMessage("Successfully deleted the unit", "success");
    	getAllUnits();
		populateDashboard();
    }

    var delUnitFail = function(res){
    	showMessage("Unable to delet unit now. Please try again later.", "error");
    }

    var initDelUnit = function() {
    	if(confirm('Delete selected unit(s)?')){
            var table1 = $('#UnitsTable').DataTable();
            var tdata = table1.rows('.selected').data();
            var unitid = tdata[0][0];
            //delete the unit
            var myurl = "api/units/" + unitid;
            console.log("deleting the unit");
            ajaxRequest(null, "DELETE", myurl, delUnitSuccess, delUnitFail);
    	}
    	return false;
    };
    $("#delUnit").on('click', initDelUnit);
	$("#delUnit1").on('click', initDelUnit);

    // 5.d. Delete unit: Ends

    // 5.e. Multicast: Starts

    var selectedUnits = [];

    var multiMsg = function() {
        var table11 = $('#UnitsTable').DataTable();
        var d = table11.rows('.selected').data();
        console.log(d);

        for (i = 0; i < d.length; i++) {
            id = d[i][0];
            var u = {};
            u["id"] = id;
            selectedUnits.push(u);
        }

        //console.log(selectedUnits);
        $('#multicastUnits').parsley().reset();
        $("#multicastUnits").trigger('reset');
        $("#multicastUnits").modal();
    };
	$('#multiMsgUnit').click(multiMsg);
    $('#multiMsgUnit1').click(multiMsg);

    var processSendMsgSuccess = function(response) {
    	showMessage("Message sent successfully", "success");
        $.modal.close();
        getMessagesData();
        //getAllUnits();
    };

    var processSendMsgFilure = function(response) {
    	showMessage("Unable to send message at this moment. Please try again later.", "error");
        $.modal.close();
        //getAllUnits();
    };

    $("#sendMsgMulti").on('click', function() {
        // get the values of the subject and body fields
    	$('#multicastUnits').parsley().validate();
    	if (false === $('#multicastUnits').parsley().isValid()) {
    		return false;
    	}

        var sub = $("#messageMultiSub").val();
        var body = $("#messageMultiBody").val();

        var msg = {};
        msg["subject"] = sub;
        msg["details"] = body;
        msg["allUnitOfOrg"] = false;
        msg["units"] = selectedUnits;
        var myurl = "api/orgs/" + orgId + "/broadcast";
        console.log("multicast msgs");
        console.log(msg);
        ajaxRequest(msg, "POST", myurl, processSendMsgSuccess, processSendMsgFilure);

    });

    $("#cancelMsgMulti").on('click', function() {
        $.modal.close();
    });

    // 5.e. Multicast: Ends

    // 5.f. Broadcast: Starts

    // 5.f. Broadcast: Ends
    // 5. Units functionalities: Ends
    // 6. Subscription functionalities: Starts

    var subsTable = $("#SubsTable").dataTable({
        //data: subsDataSet,
        responsive: true,
        bLengthChange: false,
        //"deferRender": true,
        columns: [
                  { title: "ID" },
                  { title: "LID" },
                  { title: "Name" },
                  { title: "Details" },
                  { title: "Duration" },
                  { title: "Cost" },
				  { title: "Start Date" },
				  { title: "End Date" },
                  { title: "Type" }
                 ],
        columnDefs: [{
                "targets": [0],
                "visible": false,
                "searchable": false
            },
            {
                "targets": [1],
                "visible": false,
                "searchable": false
            }
        ]
    });

    var subsDataSet = [];
    var subsData = [];
    var populateSubsTable = function(data) {
        var t = $('#SubsTable').dataTable();
        subsDataSet = [];
        subsData = data.data;
        if (subsData != null) {
            for (i = 0; i < subsData.length; i++) {
                //console.log(licenseData[i]);
                var tempdata = [];
                tempdata.push(subsData[i].id);
                var licId = "";
                var licName = "";
                var licDetails = "";
                var licDuration = "";
				var licStartDate = "";
				var licEndDate = "";
                var licCost = "";
                var licType = "";

                if(subsData[i].hasOwnProperty("license")){
                	if(!isEmpty(subsData[i].license.id)){
                		licId = subsData[i].license.id;
                	}

                	if(!isEmpty(subsData[i].license.name)){
                		licName = subsData[i].license.name;
                	}

                	if(!isEmpty(subsData[i].license.details)){
                		licDetails = subsData[i].license.details;
                	}

                	if(!isEmpty(subsData[i].license.duration)){
                		licDuration = subsData[i].license.duration;
                		if(!isEmpty(subsData[i].license.durationUOMStr)){
                			licDuration = licDuration +' ' + subsData[i].license.durationUOMStr;
                		}
                	}

					if(!isEmpty(subsData[i].startDate)){
						licStartDate = formatDate(subsData[i].startDate);
					}

					if(!isEmpty(subsData[i].endDate)){
						licEndDate = formatDate(subsData[i].endDate);
					}

                	if(!isEmpty(subsData[i].license.cost)){
                		licCost = subsData[i].license.cost;
                		if(!isEmpty(subsData[i].license.currency.prefix)){
                			licCost = licCost +' ' + subsData[i].license.currency.prefix;
                		}
                	}

                	if(!isEmpty(subsData[i].license.type) && !isEmpty(subsData[i].license.type.name)){
                		licType = subsData[i].license.type.name;
                	}
                }
                tempdata.push(licId);
                tempdata.push(licName);
                tempdata.push(licDetails);
                tempdata.push(licDuration);
				tempdata.push(licCost);
				tempdata.push(licStartDate);
				tempdata.push(licEndDate);
                tempdata.push(licType);
                subsDataSet.push(tempdata);


            }
        }

        t.fnClearTable();

        if (subsDataSet.length > 0) {
            t.fnAddData(subsDataSet);
        }

    };

    var getAllSubs = function() {
        url = "api/orgs/" + orgId + "/subscriptions?allStatus=true";
        ajaxRequest(null, "GET", url, populateSubsTable, null);
    };

    getAllSubs();

    // 6.a. Add Subscription: starts
    /*$("#addsubscription").click(function() {
        $("#addsubs").parsley().reset();
        OpenModal("add", "");
        //$("#addsubs").modal();
    });*/
    // 6.a. Add Subscription: ends

    // 6.b. Edit Subscription: starts
    var initEditSubs = function() {
        // pass the selected row to the edit page
        var table1 = $('#SubsTable').DataTable();
        var tdata = table1.rows('.selected').data();
        var subsId = tdata[0][0];


        for (var k = 0; k < subsData.length; k++) {
            if (subsData[k].id == subsId) {
            	setStorageData(KEY_ORG_SUBS_DATA, JSON.stringify(subsData[k]));
            }
        }

    	window.location.href = "society_subscription.html?action=update";
        return false;
    };
	$("#editsubscription").click(initEditSubs);
	$("#editsubscription1").click(initEditSubs);
    // 6.b. Edit Subscription: ends

    // 6.c. Delete Subscription: starts
    var deleteSubsSuccess = function(){
    	showMessage("Successfully deleted the subscription", "success");
    	getAllSubs();
		//populateDashboard();
    };

    var initDelSubs = function() {
    	if(confirm('Delete selected subscription?')){
	        var table1 = $('#SubsTable').DataTable();
	        var tdata = table1.rows('.selected').data();
	        var id = tdata[0][0];

	        var myurl = "api/orgs/" + orgId + "/subscriptions/" + id;
	        ajaxRequest(null, "DELETE", myurl, deleteSubsSuccess, null);
    	}
    	return false;
    };
	$("#remsubscription").on("click", initDelSubs);
	$("#remsubscription1").on("click", initDelSubs);
    // 6.c. Delete Subscription: ends

    // 6. Subscription functionalities: ends

    // 7. Message functionalities: Starts
    var MsgDataSet = [];

    var processMsgSuccess = function(response) {

        var data = response.data;
        console.log(data);
        MsgDataSet = [];
        for (i = 0; data != null && i < data.length; i++) {
            var tempData = [];
            if (data[i].subject.trim() != "" && data[i].details.trim() != "") {
                tempData.push(data[i].id);
                tempData.push(data[i].subject);
                tempData.push(data[i].details);
                if(!isEmpty(data[i].sentOn)){
                	//var sentDate = new Date(data[i].sentOn);
                	tempData.push(formatDateTime(data[i].sentOn));
                } else {
                	tempData.push("");
                }
                tempData.push(data[i].sentToUnits);

                 if (!isEmpty(data[i].expiryDate)) {
                     tempData.push(formatDateTime(data[i].expiryDate));

                 }
                 else{
                      tempData.push("No Expiry Date");
                 }

                

                if (!isEmpty(data[i].attachments)) {
                     //var r= $('<input type="button" value="new button"/>');
                     //tempData.push(r);
                      var attachments = [];
                      //var list = [];
                    attachments = JSON.stringify(data[i].attachments);
                    var lengthAttachemnt = Object.keys(data[i].attachments).length;
                    console.log(lengthAttachemnt);
                    

                   //for (var i = 0; i < attachments.length;i++){
                     //  list[i] = attachments[i].name;



                   //}


                    console.log(attachments);
                    //console.log(list);
                    tempData.push(lengthAttachemnt + ' Attachments');
                  //tempData.push(JSON.stringify(data[i].attachments));
                } else {
                    tempData.push("No Attachments");
                }

                MsgDataSet.push(tempData);
            }

        }

        var tb = $("#MsgTable").dataTable();
        tb.fnClearTable();
        if (MsgDataSet.length > 0) {
            tb.fnAddData(MsgDataSet);
        }

    };

    $("#MsgTable").dataTable({
        data: MsgDataSet,
        responsive: true,
        bLengthChange: false,
        //"deferRender": true,
        columns: [
            {
                title: "Id"
            },
			{ title: "Subject" },
            { title: "Details" },
            { title: "Sent On" },
            { title: "Sent To Units" },
            { title: "Expiry Date" },
            { title: "Attachments" }
        ]
    });
    var noticeId;

    $('#MsgTable tbody').on('click', 'tr', function () {
        var table = $('#MsgTable').DataTable();
        var data = table.row(this).data();
        noticeId = data[0];

        console.log(noticeId);
        console.log(data);

        setStorageData(KEY_NOTICE_ID, noticeId);


        
         window.location = "broadcastmessagedetails.html";
        //window.location.href = $(this).attr('broadcastmessagedetails.html');
    });





    

    var getMessagesData = function() {
        var myurl = "api/orgs/" + orgId + "/messages";
        ajaxRequest(null, "GET", myurl, processMsgSuccess, null);
    };



    getMessagesData();

    // 7.a. Send Message: Starts
    var initMsgForm = function() {
    	$('#msgForm').parsley().reset();
    	$("#msgForm").trigger('reset');
        $("#msgForm").modal();

		var tb = $("#UnitsTable1").dataTable();
        tb.fnClearTable();
        if (unitsDataSet.length > 0) {
            tb.fnAddData(unitsDataSet);
            tb.fnFilter('');
            $('input[type=search]').val('');
        }

        $('#UnitsTable1 tbody').on('click', 'tr', function() {
            $(this).toggleClass('selected');
            // if co
            var table12 = $('#UnitsTable1').DataTable();
            if (table12.rows('.selected').data().length >= 1) {
                // only approve button enabled
                $("#sendMsgMulti1").removeClass('disabled');
            } else {
	            $("#sendMsgMulti1").addClass('disabled');
            }
            //alert(table11.rows('.selected').data().length);
        });
    };
	$("#multiMsg").on("click", initMsgForm);
	$("#multiMsg1").on("click", initMsgForm);


    var unittable1 = $("#UnitsTable1").dataTable({
        data: unitsDataSet,
        responsive: true,
        bLengthChange: false,
        //"deferRender": true,
        columns: [
                  { title: "ID" },
                  { title: "Name" },
                  { title: "ShortName" },
                  { title: "Location" },
                  { title: "Type" },
                  { title: "Parent" }
        ],
        columnDefs: [{
            "targets": [0],
            "visible": false,
            "searchable": false
        }]
    });

    var processMsgSuccess1 = function(response) {
        console.log("Message sent successfully");
        $.modal.close();
        getMessagesData();
    };
    var attachemnstId = [];
    $("#sendMsgBroad1").on('click', function() {
        // get the values of the subject and body fields
    	$('#msgForm').parsley().validate();
    	if (false === $('#msgForm').parsley().isValid()) {
    		return false;
        }
        
        var sub = $("#messageMultiSub1").val();
        var body = $("#messageMultiBody1").val();
        var expiry = $("#messageMultiExpiry").val();


        var msg = {};
        msg["subject"] = sub;
        msg["details"] = body;
        msg["allUnitOfOrg"] = true;
        msg["expiryDate"] = expiry;
        msg["attachments"] = attachemnstId;


        var myurl = "api/orgs/" + orgId + "/broadcast";
        ajaxRequest(msg, "POST", myurl, processMsgSuccess1, null);

        return false;
    });


    


    $("#sendMsgMulti1").on('click', function() {
        // get the values of the subject and body fields
    	$('#msgForm').parsley().validate();
    	if (false === $('#msgForm').parsley().isValid()) {
    		return false;
    	}

        var sub = $("#messageMultiSub1").val();
        var body = $("#messageMultiBody1").val();
        var expiry = $("#messageMultiExpiry").val();
        var s = " 00:00:00+0000";
        var table13 = $('#UnitsTable1').DataTable();
        var d = table13.rows('.selected').data();
        console.log(d);
        var selectedUnits1 = [];
        for (i = 0; i < d.length; i++) {
            id = d[i][0];
            var u = {};
            u["id"] = id;
            selectedUnits1.push(u);
        }
        console.log(expiry+s);
        console.log(selectedUnits1);

        var msg = {};
        msg["subject"] = sub;
        msg["details"] = body;
        msg["expiryDate"] = expiry + s;
        msg["allUnitOfOrg"] = false;
        msg["units"] = selectedUnits1;
        msg["attachments"] = attachemnstId;
        var myurl = "api/orgs/" + orgId + "/broadcast";
        console.log(msg);
        ajaxRequest(msg, "POST", myurl, processMsgSuccess1, sendMessageErrorFunc);

        return false;
    });
//upload attachments
    var i = {};
    $('#upload').click(function () {

        var fd = new FormData();
        var file = $('#file')[0].files[0];
        fd.append('file', file);
        console.log(file);

        var myurl = getBaseUrl();
        myurl += "api/images";
        console.log(myurl);
        console.log(attachemnstId);
        // AJAX request
        $.ajax({
            url: myurl,
            type: "POST",
            timeout: 6000,
            data: fd,
            contentType: false,
            processData: false,
            headers: {
                'clientId': clientId,
                'Authorization': 'Bearer ' + getAccessToken()
            },
            success: function (response) {
                if (response != 0) {
                    i["id"] = JSON.stringify(response.data.id);
                    attachemnstId.push(response.data);
                    getAttach(response);
                
                  console.log("success response=" + JSON.stringify(response.data));
                } else {
                    alert('file not uploaded');
                }
            }
        });
    });
//print list of attchments in society details

var dataset = [];
var getAttach = function (response) {
    var data = response.data;
    console.log(data);

    dataset = [];
    for (var i = 0; i < attachemnstId.length; i++) {
        var tempData = [];
        tempData.push(attachemnstId[i].id);
        tempData.push(attachemnstId[i].name);
        tempData.push(formatFileSize(attachemnstId[i].size));
        tempData.push('Delete');
        dataset.push(tempData);
    }
    tempData = [];
    // dataset.push(tempData);
    console.log(tempData);
    console.log(dataset);
    var tb = $("#AttachmentsList").dataTable();
    tb.fnClearTable();
    if (dataset.length > 0) {
        tb.fnAddData(dataset);
    }

};
function formatFileSize(bytes) {
    if (typeof bytes !== 'number') {
        return '';
    }
    if (bytes >= 1000000000) {
        return (bytes / 1000000000).toFixed(2) + ' GB';
    }
    if (bytes >= 1000000) {
        return (bytes / 1000000).toFixed(2) + ' MB';
    }
    return (bytes / 1000).toFixed(2) + ' KB';
}

    $("#AttachmentsList").dataTable({
        data: dataset,
        responsive: true,
        bLengthChange: false,
        bFilter: false,
        searching: false,
        paging: false,
        info: false,
        //"deferRender": true,
        columns: [{
                title: "ID"
            },
            {
                title: "Name"
            },
            {
                title: "SIZE"
            },
            {
                title: "DELETE"
            }
        ]
    });

    var index;
    var deleteAttachmentSucess = function (res) {
        console.log(index);
        attachemnstId.pop(index);
        dataset.pop(index);
        console.log(attachemnstId);
        $('#AttachmentsList').DataTable().ajax.reload();

        //optional
        alert('Deleted');
    };

    $('#AttachmentsList tbody').on('click', 'tr', function () {
        var table = $('#AttachmentsList').DataTable();
        var data = table.row(this).data();
        index = table.row(this).index()
        attachmentId = data[0];
        console.log(attachmentId);
        console.log(data);
        var url = "api/images/" + attachmentId;
        ajaxRequest(null, 'DELETE', url, deleteAttachmentSucess, null);
    });
    $("#closeMsg").on("click", function() {
        $.modal.close();
    });

    var sendMessageErrorFunc = function(errorResponse){
    	if(errorResponse != null && errorResponse.messages != null && errorResponse.messages.length > 0){
    		for (i = 0; i < errorResponse.messages.length; i++) {
    	        msg = errorResponse.messages[i];
    			$("#sendMessageErrors").append('<li class="parsley-required">'+htmlEncode(msg.message)+'</li>');
    	    }
    	}
    };

    // 7.a. Send Message: Ends

    // 7. Message functionalities: Ends

    // 8. History functionalities: Starts
    var historyDataSet = [];
    //iterate over the json response object

    $("#HistoryTable").dataTable({
        data: historyDataSet,
        responsive: true,
        bLengthChange: false,
		order: [],
        //"deferRender": true,
        columns: [{ title: "Action By" },
                  { title: "Resource" },
                  { title: "Action" },
                  { title: "Date" },
                  { title: "Old Value" },
                  { title: "New Value" }
        ]
    });

    var populateHistoryTable = function(res) {
        historyData = res.data;
        for (i = 0; i < historyData.length; i++) {
            //console.log(historyData[i]);
            var tempdata = [];

            if(!isEmpty(historyData[i].actionBy)){
            	tempdata.push(historyData[i].actionBy.name);
            } else {
            	tempdata.push(" ");
            }
            tempdata.push(historyData[i].resourceName);
            tempdata.push(historyData[i].action);
            var histDate = new Date(historyData[i].actionDate);
            var histDateStr = histDate.getDate()+ '/'+(histDate.getMonth()+1)+'/'+histDate.getFullYear()+ ' '+histDate.getHours()+":"+histDate.getMinutes()+':'+histDate.getSeconds();
            tempdata.push(histDateStr);

            if (historyData[i].oldValue != null)
                tempdata.push(historyData[i].oldValue);
            else {
                tempdata.push(" ");
            }
            tempdata.push(historyData[i].newValue);

            historyDataSet.push(tempdata);

        }
        var tb = $("#HistoryTable").dataTable();
        tb.fnClearTable();
        if (historyDataSet.length > 0) {
            tb.fnAddData(historyDataSet);
        }

    };

	var historyUrl = "api/audits";
	historyUrl = historyUrl+"?orgId=" + orgId;
	ajaxRequest(null, 'GET', historyUrl, populateHistoryTable, null);

    // 8. History functionalities: Ends
    /*
    Units Table Start
    1. Get all units for soc
    2. Add Unit
    3. Edit Unit
    4. Delete Unit
    */



    var table11 = $('#UnitsTable').DataTable();
    $('#UnitsTable tbody').on('click', 'tr', function() {
        $(this).toggleClass('selected');
        // if co
        var table11 = $('#UnitsTable').DataTable();
        // console.log(table11.rows('.selected').data().length);
        if (table11.rows('.selected').data().length > 1) {
            // only approve button enabled
            $("#multiMsgUnit").removeClass('disabled');
			$("#multiMsgUnit1").removeClass('disabled');
            if (!$("#editUnit").hasClass('disabled')) {
                $("#editUnit").addClass('disabled');
            }
			if (!$("#editUnit1").hasClass('disabled')) {
                $("#editUnit1").addClass('disabled');
            }
            if (!$("#delUnit").hasClass('disabled')) {
                $("#delUnit").addClass('disabled');
            }
			if (!$("#delUnit1").hasClass('disabled')) {
                $("#delUnit1").addClass('disabled');
            }
        } else
        if (table11.rows('.selected').data().length == 1) {
            $("#multiMsgUnit").removeClass('disabled');
			$("#multiMsgUnit1").removeClass('disabled');
            $("#editUnit").removeClass('disabled');
			$("#editUnit1").removeClass('disabled');
            $("#delUnit").removeClass('disabled');
			$("#delUnit1").removeClass('disabled');

        } else {
            $("#editUnit").addClass('disabled');
			$("#editUnit1").addClass('disabled');
            $("#delUnit").addClass('disabled');
			$("#delUnit1").addClass('disabled');
            $("#multiMsgUnit").addClass('disabled');
			$("#multiMsgUnit1").addClass('disabled');
        }

        //alert(table11.rows('.selected').data().length);
    });


    var processUnitErrors = function(errors) {
        console.log(errors);
    }

    var editUnit = function() {
        // pass the selected row to the edit page
        var table1 = $('#UnitsTable').DataTable();
        var tdata = table1.rows('.selected').data();
        var unitid = tdata[0][0];
        console.log(tdata);

        var myurl = "api/units/" + unitid;
        // get unitbyid
        ajaxRequest(null, "GET", myurl, populateUnitsData, null);

        // open the createunitform and fill the values
    };



    var openUploadModal = function() {
        $("#uploadUnitsForm").modal();
    };
	$("#uploadUnits").on('click', openUploadModal);
	$("#uploadUnits1").on('click', openUploadModal);

    var initDwldUnit = function() {
        var url = baseurl + "api/orgs/" + orgId + "/bulk/template";
		window.open(url);
    };
	$('#downloadUnitTemplate').on('click', initDwldUnit);
    $('#downloadUnitTemplate1').on('click', initDwldUnit);

    var myurl = getBaseUrl();
    myurl += "api/orgs/" + orgId + "/bulk";
    Dropzone.options.unitsUpload = {
        maxFilesize: 1,
		maxFiles: 1,
        addRemoveLinks: true,
        dictResponseError: 'Server not Configured',
		dictDefaultMessage: 'Drop file here or click to upload',
		dictCancelUpload: 'Uploading. Cancel Upload.',
        acceptedFiles: ".xls,.xlsx",
		headers: {
            'clientId': clientId,
            'Authorization': 'Bearer ' + getAccessToken()
        },
        url: myurl,
        init: function() {
            var dz = this;
            // config
            this.options.addRemoveLinks = true;
            this.options.dictRemoveFile = "Delete";
            //New file added
            this.on("addedfile", function(file) {
                console.log('new file added ', file);
            });
            // Send file starts
            this.on("sending", function(file) {
				$('.dz-success-mark').hide();
				$('.dz-error-mark').hide();
                console.log('upload started', file);
                //$('.meter').show();
            });

            this.on("error", function(file, error, xhr) {
				console.log('upload error');
                console.log(xhr.responseText);
                $(file.previewElement).find('.dz-error-message').text('Unable to upload file at this moment. Please try again later.');
            });
            // File upload Progress
            this.on("totaluploadprogress", function(progress) {
                //console.log("progress ", progress);
                $('.roller').width(progress + '%');
            });

			this.on("success", function(eventObj, response) {
				$('.dz-success-mark').hide();
				$('.dz-error-mark').hide();
				$('#unitUploadSuccess').show();
                console.log('upload completed');
                console.log(response);
            });

            // On removing file
            this.on("removedfile", function(file) {
                console.log(file);
            });
			$("#uploadUnits").on('click', function() {
				dz.removeAllFiles();
				$('#unitUploadSuccess').hide();
			});
        }
    };

	$('#dwldUnitFile').on('click', function() {
        var url = baseurl + "api/orgs/" + orgId + "/bulk/result";
		window.open(url);
		return false;
    });


    $("#uploadUnitsToServer").on('click', function() {

    });

    $("#cancelUpload").on('click', function() {
        $.modal.close();
    });

    $("#cancelUploadUnits").on('click', function() {
        $.modal.close();
    });
    var closeAddUnit = function() {
        $('#createUnitForm').parsley().reset();
        $.modal.close();
    }
    $("#cancelAddUnit").on('click', function() {
        closeAddUnit();
    });

    /*
    Units Table End
    */


    var initDwldUser = function() {
        // call the get method

        var url = baseurl + "api/orgs/" + orgId + "/users/bulk/template";
		window.open(url);
    };
	$('#downloadUserTemplate').on('click', initDwldUser);
	$('#downloadUserTemplate1').on('click', initDwldUser);

    $('#UsersTable tbody').on('click', 'tr', function() {

        $(this).toggleClass('selected');

        var table11 = $('#UsersTable').DataTable();
        // console.log(table11.rows('.selected').data().length);
        if (table11.rows('.selected').data().length > 1) {
            // only approve button enabled
            $("#verUser").removeClass('disabled');


            if (!$("#editUser").hasClass('disabled')) {
                $("#editUser").addClass('disabled');
            }
			if (!$("#editUser1").hasClass('disabled')) {
                $("#editUser1").addClass('disabled');
            }
            if (!$("#delUser").hasClass('disabled')) {
                $("#delUser").addClass('disabled');
            }
            if (!$("#delUser1").hasClass('disabled')) {
                $("#delUser1").addClass('disabled');
            }
        } else
        if (table11.rows('.selected').data().length == 1) {
            $("#verUser").removeClass('disabled');
			$("#verUser1").removeClass('disabled');
            $("#actDactUser").removeClass('disabled');
            $("#actDactUser1").removeClass('disabled');
            $("#editUser").removeClass('disabled');
			$("#editUser1").removeClass('disabled');
            $("#delUser").removeClass('disabled');
            $("#delUser1").removeClass('disabled');


        } else {
            $("#editUser").addClass('disabled');
            $("#delUser").addClass('disabled');
            $("#verUser").addClass('disabled');
            $("#actDactUser").addClass('disabled');
			$("#editUser1").addClass('disabled');
            $("#delUser1").addClass('disabled');
            $("#verUser1").addClass('disabled');
            $("#actDactUser1").addClass('disabled');
        }
    });

    $.modal.defaults = {
        width: 700,
        closeExisting: true, // Close existing modals. Set this to false if you need to stack multiple modal instances.
        escapeClose: false, // Allows the user to close the modal by pressing `ESC`
        clickClose: false, // Allows the user to close the modal by clicking the overlay
        closeText: 'Close', // Text content for the close <a> tag.
        closeClass: '', // Add additional class(es) to the close <a> tag.
        showClose: false, // Shows a (X) icon/link in the top-right corner
        modalClass: "modal", // CSS class added to the element being displayed in the modal.
        spinnerHtml: null, // HTML appended to the default spinner during AJAX requests.
        showSpinner: true, // Enable/disable the default spinner during AJAX requests.
        fadeDuration: null, // Number of milliseconds the fade transition takes (null means no transition)
        fadeDelay: 1.0 // Point during the overlay's fade-in that the modal begins to fade in (.5 = 50%, 1.5 = 150%, etc.)
    };

    /*
    Users Table Ends
    */

    var licenses = [];
    var subsAction = "add";
    // TODO: Vinit we may not need this call here.
    var myurl1 = "api/licenses/";

    var processLicenseData = function(response) {
        licenses = response.data;

        for (i = 0; i < licenses.length; i++) {
            console.log(licenses[i].name);
            // fill up the select input now with options
            $('#licenseList').append($('<option>', {
                sno: i,
                value: licenses[i].id,
                text: licenses[i].name,
                cost: licenses[i].cost,
                curr: licenses[i].currency.prefix,
                sdate: licenses[i].startDate,
                edate: licenses[i].endDate
            }));
        }
        $("#cost").prop("value", (licenses[0].cost + " " + licenses[0].currency.prefix));
        $("#curr").html(licenses[0].currency.prefix);
    };

    ajaxRequest(null, "GET", myurl1, processLicenseData, null);

    var close = function() {
        console.log("Inside close");
        console.log("Reset");
        $('#addsubs').parsley().reset();
        //$('#addUserForm').parsley().reset();
        $.modal.close();
    }



    var validateFront = function() {
        if (true === $('#addsubs').parsley().isValid()) {
            console.log("here");
            $('.bs-callout-info').removeClass('hidden');
            $('.bs-callout-warning').addClass('hidden');
            subscribe();
        } else {
            console.log("and here");
            $('.bs-callout-info').addClass('hidden');
            $('.bs-callout-warning').removeClass('hidden');
        }
    };


    $('#addsubs .btn').on('click', function() {
        console.log("validating");
        $('#addsubs').parsley().validate();
        if (validateFront()) {
            console.log("Calling subscribe");
            subscribe();
        }
    });


    var initUploadUser = function() {
        $("#uploadUserFile").modal();
    };
	$("#uploadUserTemplate").on('click', initUploadUser);
	$("#uploadUserTemplate1").on('click', initUploadUser);

    var userBulkUrl = getBaseUrl();
    userBulkUrl += "api/orgs/" + orgId + "/users/bulk";
    Dropzone.options.usersUpload = {
        maxFilesize: 1,
		maxFiles: 1,
        addRemoveLinks: true,
        dictResponseError: 'Server not Configured',
		dictDefaultMessage: 'Drop file here or click to upload',
		dictCancelUpload: 'Uploading. Cancel Upload.',
        acceptedFiles: ".xls,.xlsx",
		headers: {
            'clientId': clientId,
            'Authorization': 'Bearer ' + getAccessToken()
        },
        url: userBulkUrl,
        init: function() {
            var dz = this;
            // config
            this.options.addRemoveLinks = true;
            this.options.dictRemoveFile = "Delete";
            // Send file starts
            this.on("sending", function(file) {
				$('.dz-success-mark').hide();
				$('.dz-error-mark').hide();
            });

            this.on("error", function(file, error, xhr) {
                $(file.previewElement).find('.dz-error-message').text('Unable to upload file at this moment. Please try again later.');
            });
            // File upload Progress
            this.on("totaluploadprogress", function(progress) {
                //console.log("progress ", progress);
                //$('.roller').width(progress + '%');
            });

			this.on("success", function(eventObj, response) {
				$('.dz-success-mark').hide();
				$('.dz-error-mark').hide();
				$('#userUploadSuccess').show();
            });

			$("#uploadUserTemplate").on('click', function() {
				dz.removeAllFiles();
				$('#userUploadSuccess').hide();
			});
        }
    };

	$('#dwldUserFile').on('click', function() {
        var url = baseurl + "api/orgs/" + orgId + "/users/bulk/result";
		window.open(url);
		return false;
    });



    //TODO: Vinit - this is not required.
    var OpenModal = function(action, data) {
        $("#addsubs").modal();
        if (action == "edit") {
            // populate form data and make a put request
            // populate the licenselist first
            var id = data[0][1];
            subid = data[0][0];
            // populate select with this id
            $("#licenseList").val(id).change();
            // populate the start date
            // get the start date first from the option itself
            var licenseStartDate = $("#licenseList").find('option:selected').attr("sdate");
            var licenseEndDate = $("#licenseList").find('option:selected').attr("edate");
            // call getlicensebyid here or get the values from licenses
            var d1;
            var d2;
            var d3;
            var d4;
            for (var k = 0; k < subsData.length; k++) {
                console.log(subsData[k]);
                if (subsData[k].id == subid) {
                    d1 = subsData[k].startDate;
                    var arrDate = d1.split(" ");
                    d3 = arrDate[0];

                    console.log(d1);

                    d2 = subsData[k].endDate;
                    arrDate = d2.split(" ");
                    d4 = arrDate[0];
                    console.log(d2);
                }
            }
            var arrs = licenseStartDate.split(" ");
            var arre = licenseEndDate.split(" ");
            $("#startdate").prop("value", d3);
            $("#enddate").prop("value", d4);
            //$("#startdate").prop("value",arrs[0]);
            //$("#enddate").prop("value",arre[0]);
            subsAction = "edit";
        } else {
            // just submit
            //var id = data[0][0];
            subsAction = "add";
            console.log("adding subs");
            if (!$("#sdateError").hasClass("hide")) {
                $("#sdateError").addClass("hide");
            }
            if (!$("#edateError").hasClass("hide")) {
                $("#edateError").addClass("hide");
            }

            $("#licenseList").val("1").change();
            $("#startdate").prop("value", "");
            $("#enddate").prop("value", "");
        }
    };





    $("#startdate").on("change", function() {
        if (!$("#sdateError").hasClass("hide")) {
            $("#sdateError").addClass("hide");
        }
    });

    $("#enddate").on("change", function() {
        if (!$("#edateError").hasClass("hide")) {
            $("#edateError").addClass("hide");
        }
    });



    $('#SubsTable tbody').on('click', 'tr', function() {
        if ($(this).hasClass('selected')) {
            $(this).removeClass('selected');
            $("#editsubscription").addClass('disabled');
			$("#editsubscription1").addClass('disabled');
            $("#remsubscription").addClass('disabled');
            $("#remsubscription1").addClass('disabled');

        } else {
            subsTable.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
            $("#editsubscription").removeClass('disabled');
			$("#editsubscription1").removeClass('disabled');
            $("#remsubscription").removeClass('disabled');
            $("#remsubscription1").removeClass('disabled');
        }
    });

	var filterUser = function(){

		var userFilter = $("#userFilter").val();
		var userTb2 = $("#UsersTable").DataTable();

		if(!isEmpty(userFilter)){
			if(userFilter == 'All'){
				// clear search
				clearUserTableSearch();
			} else if(userFilter == 'Active'){
				// Active only
				clearUserTableSearch();
				userTb2.columns(3)
					.search( 'Active', false, false, false)
					.draw();

			} else if(userFilter == 'Inactive'){
				// Inactive only
				clearUserTableSearch();
				userTb2.columns(3)
					.search( input='Inactive', false, false, false)
					.draw();
			} else if(userFilter == 'Approved'){
				// Approved only
				clearUserTableSearch();
				userTb2.columns(2)
					.search( 'Yes', false, false, false)
					.draw();
			} else if(userFilter == 'Unapproved'){
				// Approved only
				clearUserTableSearch();
				userTb2.columns(2)
					.search( 'No', false, false, false)
					.draw();
			}
		}

    };
    
    
	var clearUserTableSearch = function(){
		var userTb2 = $("#UsersTable").DataTable();
		userTb2.columns([2,3])
				.search('')
				.draw();
	}

	$("#userFilter").change(filterUser);

});
